<div class="row">
  <div class="col-xl-12">
      <div class="card">
          <div class="card-body">
            <form wire:submit.prevent="submit">
              <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="partnercode">Partner Code</label>
                  <input type="text" class="form-control" id="inputEmail4" placeholder="" wire:model="PartnerCode">
                  <?php $__errorArgs = ['PartnerCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-6">
                  <label for="windowname">Window Name</label>
                  <input type="text" class="form-control" id="inputPassword4" placeholder="" wire:model="WindowName">
                  <?php $__errorArgs = ['WindowName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="auth_person">Authorised Person</label>
                    <input type="text" class="form-control" id="inputEmail4" placeholder="" wire:model="AuthorisedPerson">
                    <?php $__errorArgs = ['AuthorisedPerson'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="contact_num">Contact No</label>
                    <input type="text" class="form-control" id="inputPassword4" placeholder="" wire:model="ContactNo">
                    <?php $__errorArgs = ['ContactNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
              </div>
              <div class="form-group">
                <label for="address">Address</label>
                <input type="text" class="form-control" id="inputAddress" placeholder="" wire:model="Address">
                <?php $__errorArgs = ['Address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="latlong">Lat Long</label>
                    <input type="text" class="form-control" id="inputEmail4" placeholder="" wire:model="LatLong">
                    <?php $__errorArgs = ['LatLong'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="area">Area</label>
                    <input type="text" class="form-control" id="inputPassword4" placeholder="" wire:model="Area">
                    <?php $__errorArgs = ['Area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
              </div>
              <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="zone">Zone</label>
                    <input type="text" class="form-control" id="inputEmail4" placeholder="" wire:model="Zone">
                    <?php $__errorArgs = ['Zone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="region">Region</label>
                    <input type="text" class="form-control" id="inputPassword4" placeholder="" wire:model="Region">
                    <?php $__errorArgs = ['Region'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
              </div>
              <div class="form-row">  
                <div class="form-group col-md-6">
                  <label for="city">City</label>
                  <input type="text" class="form-control" id="" wire:model="City">
                  <?php $__errorArgs = ['City'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-6">
                  <label for="infra">Infrastructure</label>
                  <input type="text" class="form-control" id="" wire:model="Infra">
                  <?php $__errorArgs = ['Infra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <button type="submit" class="btn btn-primary float-center">Submit</button>
            </form>
          </div> <!-- end card-body -->
        </div> <!-- end card-->
    </div> <!-- end col --><?php /**PATH C:\xamppp\htdocs\excitelpnt\resources\views/livewire/erp-add-form.blade.php ENDPATH**/ ?>