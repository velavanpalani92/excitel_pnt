
<div class="table-responsive">

  <table class="table table-centered table-nowrap table-striped" id="products-datatable">
        <thead>
          <tr>
            <th scope="col">Partner Code</th>
            <th scope="col">Window Name</th>
            <th scope="col">Authorised Person</th>
            <th scope="col">Contact No</th>
            <th scope="col">Zone</th>
            <th scope="col">City</th>
            <th scope="col">Region</th>
            <th scope="col">Actions</th>

          </tr>
        </thead>
        <tbody>
        
        <?php $__currentLoopData = $erps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($erp->partnercode); ?></td>
            <td><?php echo e($erp->windowname); ?></td>
            <td><?php echo e($erp->auth_person); ?></td>
            <td><?php echo e($erp->contact_num); ?></td>
            <td><?php echo e($erp->zone); ?></td>
            <td><?php echo e($erp->city); ?></td>
            <td><?php echo e($erp->region); ?></td>
            <td>
              <a href="javascript:void(0);" class="action-icon"> <i class="mdi mdi-eye"></i></a>
              <a href="javascript:void(0);" class="action-icon"> <i class="mdi mdi-square-edit-outline"></i></a>
              <a href="javascript:void(0);" class="action-icon"> <i class="mdi mdi-delete"></i></a>
          </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>


</div><?php /**PATH C:\xamppp\htdocs\excitelpnt\resources\views/livewire/erp-listing.blade.php ENDPATH**/ ?>