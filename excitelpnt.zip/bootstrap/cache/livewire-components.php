<?php return array (
  'erp-add-form' => 'App\\Http\\Livewire\\ErpAddForm',
  'erp-listing' => 'App\\Http\\Livewire\\ErpListing',
  'erp-view' => 'App\\Http\\Livewire\\ErpView',
);