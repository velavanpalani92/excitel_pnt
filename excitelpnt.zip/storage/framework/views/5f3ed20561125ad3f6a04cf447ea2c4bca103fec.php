<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8" />
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(config('app.name', 'Laravel')); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Strikeweb" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- App favicon -->
        <link rel="shortcut icon" href=<?php echo e(asset('assets/images/favicon.ico')); ?>>

	    <!-- App css -->
	    <link href=<?php echo e(asset('assets/css/bootstrap-purple.min.css')); ?> rel="stylesheet" type="text/css" id="bs-default-stylesheet" />
	    <link href=<?php echo e(asset('assets/css/app-purple.min.css')); ?> rel="stylesheet" type="text/css" id="app-default-stylesheet" />

	    <link href=<?php echo e(asset('assets/css/bootstrap-purple-dark.min.css')); ?> rel="stylesheet" type="text/css" id="bs-dark-stylesheet" disabled />
	    <link href=<?php echo e(asset('assets/css/app-purple-dark.min.css')); ?> rel="stylesheet" type="text/css" id="app-dark-stylesheet"  disabled />

	    <!-- icons -->
	    <link href=<?php echo e(asset('assets/css/icons.min.css')); ?> rel="stylesheet" type="text/css" />
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>

    <body>

        <!-- Begin page -->
        <div id="wrapper">

            <!-- Topbar Start -->
            <?php echo $__env->make('sections.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- end Topbar -->

            <!-- ========== Left Sidebar Start ========== -->
            <?php echo $__env->make('sections.left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 

                        <!-- Dashboard Start-->

                            <?php echo $__env->make('sections.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <!-- Dashboard End-->
                        
                    </div> <!-- container -->

                </div> <!-- content -->

                <!-- Footer Start -->
                <?php echo $__env->make('sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->

        <!-- Right Sidebar -->
        <?php echo $__env->make('sections.right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

        <!-- Vendor js -->
        <script src=<?php echo e(asset('assets/js/vendor.min.js')); ?>></script>

        <!-- Third Party js-->
        <script src=<?php echo e(asset('assets/libs/apexcharts/apexcharts.min.js')); ?>></script>
        <script src="https://apexcharts.com/samples/assets/ohlc.js"></script>


        <!-- CRM Dashboard init js-->
        <script src=<?php echo e(asset('assets/js/pages/crm-dashboard.init.js')); ?>></script>

        <!-- App js -->
        <script src=<?php echo e(asset('assets/js/app.min.js')); ?>></script>
        <?php echo \Livewire\Livewire::scripts(); ?>    
    </body>
</html><?php /**PATH C:\xamppp\htdocs\excitelpnt\resources\views/layouts/app.blade.php ENDPATH**/ ?>