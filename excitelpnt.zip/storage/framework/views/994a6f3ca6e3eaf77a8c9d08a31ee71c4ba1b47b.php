

<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('erp-add-form')->html();
} elseif ($_instance->childHasBeenRendered('7GOSeQl')) {
    $componentId = $_instance->getRenderedChildComponentId('7GOSeQl');
    $componentTag = $_instance->getRenderedChildComponentTagName('7GOSeQl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7GOSeQl');
} else {
    $response = \Livewire\Livewire::mount('erp-add-form');
    $html = $response->html();
    $_instance->logRenderedChild('7GOSeQl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>;

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\excitelpnt\resources\views/pages/erp-add-page.blade.php ENDPATH**/ ?>