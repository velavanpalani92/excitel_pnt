<?php

namespace App\Models\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ERP extends Model
{

    public $table = 'e_r_p_s';

    protected $guarded = [];
}
