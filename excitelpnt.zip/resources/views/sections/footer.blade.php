<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <script>document.write(new Date().getFullYear())</script> &copy; <a href="">Excitel PNT</a> 
            </div>
        </div>
    </div>
</footer>
<!-- end Footer -->